 use Travego;
 
 # 1  How many female passengers traveled a minimum distance of 600KMs?
 select * from passenger where gender= 'F'
 and distance>=600;

 # 2 write a query to display the passenger details whose traveld is distance is greater than 500 and who are traveling in a sleeper bus.
select  * from passenger where distance >=500 and 
bus_type='sleeper';

# 3 Select passenger names whose names start with the character'S'.
select* from passenger where passenger_name like 's%';

# 4 Calculate the price charged for each passenger,displaying the Passengername,BoardingCity,DestinationCity,Bustype,and Price in the output.
select passenger.passenger_name,passenger.boarding_city,passenger.destination_city,passenger.
bus_type,price.price from passenger,price where passenger.distance = price.distance;

# 5 What are the passenger name(s) and the ticket price for those who traveled 1000 KMs Sitting in a bus
SELECT passenger.passenger_name,price.price 
from passenger,price where passenger.distance > 1000 and passenger.bus_type = 'Sitting';



# 6 What will be the Sitting and Sleeper buscharge for Pallavi to travel from Bangalore to Panaji
select * from passenger where passenger_name = 'pallavi';
select bus_type,price from price where 
distance = (select distance from passenger where passenger_name = 'Pallavi');


# 7 Alter  thec olumn category with the value "Non-AC" where the  Bus_Type is sleeper
update passenger set category = 'Non-Ac' where bus_type='sleeper';

## 8 Delete an entry from the table where the passenger name is Piyush and committ his change in the database.
delete  from passenger where passenger_name like 'piyush';
commit;

# 9 Truncate the table passenger and comment on the number of rows in the table (explain if required).
truncate passenger;
select * from passenger;

# 10 Delete the table passenger from the database
drop table passenger;